<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0"><?php echo e($menu); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e('dashboard'); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active"><?php echo e($menu); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <?php if($setting != null): ?>
        <section class="content">
            <div class="container-fluid">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="float-right">
                                <a href="#" class="btn btn-warning btn-xs text-white" data-toggle="modal"
                                    data-target="#modal-lg<?php echo e($setting->id); ?>">
                                    <i class="fa fa-edit">
                                    </i></a>
                            </div>
                        </div>
                        <div class=" table-responsive table-hover">
                            <table class="table">
                                <tr>
                                    <td rowspan="4" style="width:4%">
                                        <span class="badge badge-primary btn-sm"> <?php echo e($setting->judul); ?></span>
                                        
                                        <?php if(date('Y-m-d') < $setting->tgl_mulai && date('H:i:s') < $setting->jam_mulai): ?>
                                            <span class="badge badge-warning btn-sm text-white">sesi belum dimulai</span>
                                        <?php elseif(date('Y-m-d') == $setting->tgl_mulai && date('H:i:s') < $setting->jam_mulai): ?>
                                            <span class="badge badge-warning btn-sm text-white">sesi belum dimulai</span>
                                        <?php elseif(date('Y-m-d') > $setting->tgl_mulai ||
                                                (date('Y-m-d') == $setting->tgl_mulai && date('Y-m-d') < $setting->tgl_selesai) ||
                                                (date('Y-m-d') == $setting->tgl_selesai &&
                                                    date('H:i:s') > $setting->jam_mulai &&
                                                    date('H:i:s') < $setting->jam_selesai)): ?>
                                            <span class="badge badge-success btn-sm">aktif</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger btn-sm">sesi telah berakhir</span>
                                        <?php endif; ?>
                                        
                                    </td>
                                    <td style="width:4%">
                                        Tanggal Mulai
                                    </td>
                                    <td style="width:0%">
                                        :
                                    </td>
                                    <td style="width:20%">
                                        <?php echo e(\Carbon\Carbon::parse($setting->tgl_mulai)->translatedFormat('l, d F Y')); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Tanggal Selesai
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($setting->tgl_selesai)->translatedFormat('l, d F Y')); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Jam Mulai
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <?php echo e($setting->jam_mulai); ?> WIB
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Jam Selesai
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <?php echo e($setting->jam_selesai); ?> WIB
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <div class="modal fade" id="modal-lg<?php echo e($setting->id); ?>">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Jadwal</h4>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>Ketentuan :</h6>
                            <small>
                                *Tanggal mulai harus diatas atau sama dengan tanggal sekarang.<br>
                                *Tanggal selesai harus diatas atau sama dengan tanggal mulai.<br>
                                *Penentuan jam mulai dan jam selesai dalam rentang waktu 12 jam.<br>
                                Contoh :
                            </small><br><small class="ml-4">08:00 - 23:59 WIB&nbsp;<i
                                    class="fa fa-check-circle"></i></small><br>
                            <small class="ml-4">08:00 - 01:00 WIB&nbsp;<i class="fa fa-ban"></i></small>
                        </div>
                        <div class="card">
                            <form method="POST" action="<?php echo e(route('setting.update', $setting->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Judul SPM <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="judul" placeholder="Judul SPM"
                                            autocomplete="off" value="<?php echo e(old('judul', $setting->judul)); ?>">
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Tanggal Mulai</label>
                                                <input type="date" class="form-control" name="tglm"
                                                    value="<?php echo e(old('tglm', $setting->tgl_mulai)); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Tanggal Selesai</label>
                                                <input type="date" class="form-control" name="tgls"
                                                    value="<?php echo e(old('tgls', $setting->tgl_selesai)); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Jam Mulai</label>
                                                <input type="time" class="form-control" name="jamm"
                                                    value="<?php echo e(old('jamm', $setting->jam_mulai)); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Jam Selesai</label>
                                                <input type="time" class="form-control" name="jams"
                                                    value="<?php echo e(old('jams', $setting->jam_selesai)); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <button type="button" class="btn btn-default btn-sm"
                                            data-dismiss="modal">Kembali</button>
                                        <button type="submit" class="btn btn-primary btn-sm">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="container-fluid">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-right">
                            <a href="#" class="btn btn-info btn-xs"data-toggle="modal" data-target="#modal-lg">
                                <i class="fa fa-plus-circle">
                                </i></a>
                        </div>
                    </div>
                    <div class="card-body text-center">
                        <h6>Opss, jadwal belum diatur . . .</h6><br>
                        <img class="mb-0" src="<?php echo e(url('dist/img/ils/not-found-data.jpg')); ?>" width="400px">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modal-lg">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Jadwal</h4>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>Ketentuan :</h6>
                            <small>
                                *Tanggal mulai harus diatas atau sama dengan tanggal sekarang.<br>
                                *Tanggal selesai harus diatas atau sama dengan tanggal mulai.<br>
                                *Penentuan jam mulai dan jam selesai dalam rentang waktu 12 jam.<br>
                                Contoh :
                            </small><br><small class="ml-4">08:00 - 23:59 WIB&nbsp;<i
                                    class="fa fa-check-circle"></i></small><br>
                            <small class="ml-4">08:00 - 01:00 WIB&nbsp;<i class="fa fa-ban"></i></small>
                        </div>
                        <div class="card">
                            <form method="POST" action="<?php echo e(route('setting.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Judul SPM <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="judul"
                                            placeholder="Judul SPM" autocomplete="off" value="<?php echo e(old('judul')); ?>">
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Tanggal Mulai</label>
                                                <input type="date" class="form-control" name="tglm"
                                                    value="<?php echo e(old('tglm')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Tanggal Selesai</label>
                                                <input type="date" class="form-control" name="tgls"
                                                    value="<?php echo e(old('tgls')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Jam Mulai</label>
                                                <input type="time" class="form-control" name="jamm"
                                                    value="<?php echo e(old('jamm')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Jam Selesai</label>
                                                <input type="time" class="form-control" name="jams"
                                                    value="<?php echo e(old('jams')); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <button type="button" class="btn btn-default btn-sm"
                                            data-dismiss="modal">Kembali</button>
                                        <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/admin/setting/data.blade.php ENDPATH**/ ?>