<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="card mt-4">
                <div class="card-header">
                    <span class="text-bold"><?php echo e($menu); ?></span>
                </div>
                <div class="card-body">
                    <div class="col-12">
                        <div class="row">
                            <div class="col-2">
                                <div>Kegiatan</div>
                            </div>
                            <div class="col-10">
                                <div>: <?php echo e($subkegiatan->kegiatan->kode_kegiatan ?? 'None'); ?>

                                    <?php echo e($subkegiatan->kegiatan->nama_kegiatan ?? 'None'); ?></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-2">
                                <div>Sub Kegiatan</div>
                            </div>
                            <div class="col-10">
                                <div>: <?php echo e($subkegiatan->kode_sub ?? 'None'); ?> <?php echo e($subkegiatan->nama_sub ?? 'None'); ?></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-2">
                                <div>Bagian</div>
                            </div>
                            <div class="col-10">
                                <div>: <?php echo e($subkegiatan->kegiatan->bagian->nama_bagian ?? 'None'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo e(route('kartu.subkeg', Crypt::encryptString($subkegiatan->kegiatan->id))); ?>"
                                id="createNewSubkeg" class="btn btn-warning btn-xs float-right">
                                <i class="fas fa-reply"></i> Kembali
                            </a>
                        </div>
                        <div class="card-body">
                            <table id="data-table" class="table table-bordered table-striped ">
                                <thead>
                                    <tr>
                                        <th style="width:3%">No</th>
                                        <th style="width:15%">Kode Rekening</th>
                                        <th>Nama Rekening</th>
                                        <th style="width:13%">Jumlah</th>
                                        <th style="width:13%">Sisa</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            $.ajaxSetup({
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
                },
            });

            var table = $("#data-table").DataTable({
                processing: true,
                serverSide: true,
                responsive: true,
                lengthChange: false,
                autoWidth: false,
                dom: 'Bfrtip',
                buttons: ["excel", "pdf", "print", "colvis"],
                ajax: "<?php echo e(route('kartu.rek', $id)); ?>",
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'kode_rekening',
                        name: 'kode_rekening'
                    },
                    {
                        data: 'nama_rekening',
                        name: 'nama_rekening'
                    },
                    {
                        data: 'pagu_rekening',
                        name: 'pagu_rekening'
                    },
                    {
                        data: 'sisa_rekening',
                        name: 'sisa_rekening'
                    },
                ]
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/admin/kartukendali/rekadm.blade.php ENDPATH**/ ?>