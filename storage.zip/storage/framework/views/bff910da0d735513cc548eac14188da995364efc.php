<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0"><?php echo e($menu); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e('dashboard'); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active"><?php echo e($menu); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="col-12">
                <div class="box-shadow mb-5">
                    <div class="title mb-3">
                        <h3>Filter Berdasarkan : </h3>
                    </div>
                    <div class="row-kartu">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Bagian</label>
                                <select class="form-control select2bs4" style="width: 100%;">
                                    <option selected="selected">::Pilih Bagian::</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Kegiatan</label>
                                <select class="form-control select2bs4" style="width: 100%;">
                                    <option selected="selected">::Pilih Kegiatan::</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Sub Kegiatan</label>
                                <select class="form-control select2bs4" style="width: 100%;">
                                    <option selected="selected">::Pilih Sub Kegiatan::</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="input-group-append mt-10" id="#">
                                <button type="button" class="btn btn-block btn-primary btn-flat">
                                    Search <i class="fas fa-search"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mt-4">
                    <div class="card-body">
                        <table class="table table-bordered table-striped data-table">
                            <thead>
                                <tr>
                                    <th style="width:3%">No</th>
                                    <th style="width:15%">Kode Kegiatan</th>
                                    <th>Nama Kegiatan</th>
                                    <th style="width:15%">Bagian</th>
                                    <th style="width:13%">Jumlah</th>
                                    <th style="width:13%">Sisa</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            $.ajaxSetup({
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
                },
            });

            var table = $(".data-table").DataTable({
                processing: true,
                serverSide: true,
                responsive: true,
                lengthChange: false,
                autoWidth: false,
                dom: 'Bfrtip',
                buttons: ["excel", "pdf", "print", "colvis"],
                ajax: "<?php echo e(route('kartu.kegiatan')); ?>",
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'kode_kegiatan',
                        name: 'kode_kegiatan'
                    },
                    {
                        data: 'nama_kegiatan',
                        name: 'nama_kegiatan'
                    },
                    {
                        data: 'bagian',
                        name: 'bagian'
                    },
                    {
                        data: 'pagu_kegiatan',
                        name: 'pagu_kegiatan'
                    },
                    {
                        data: 'sisa_kegiatan',
                        name: 'sisa_kegiatan'
                    },
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/admin/kartukendali/kegadm.blade.php ENDPATH**/ ?>