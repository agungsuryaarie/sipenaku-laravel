<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<?php echo $__env->make('admin.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <?php echo $__env->make('admin.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <a href="<?php echo e('/dashboard'); ?>" class="brand-link">
                <img src="<?php echo e(url('dist/img/logo.png')); ?>" alt="Logo Batu Bara" class="brand-image">
                <span class="brand-text font-weight-light"><b>SIPENAKU</b></span>
            </a>
            <div class="sidebar">
                <div class="user-panel mt-3 pb-3 mb-1 d-flex">
                    <div class="image">
                        <?php if(Auth::user()->foto == null): ?>
                            <img src="<?php echo e(url('fotouser/blank.png')); ?>" class="img-circle elevation-2" alt="User Image">
                        <?php else: ?>
                            <img src="<?php echo e(url('storage/fotouser/' . Auth::user()->foto)); ?>"
                                class="img-circle elevation-2" alt="User Image">
                        <?php endif; ?>
                    </div>
                    <div class="info">
                        <a href="<?php echo e(route('myprofil.index')); ?>" class="d-block"><?php echo e(Auth::user()->nama); ?></a>
                        <small class="text-muted">
                            <?php if(Auth::user()->level == 1): ?>
                                administrator
                            <?php else: ?>
                                user
                            <?php endif; ?>
                        </small>
                    </div>
                </div>
                <center>
                    <small class="text-white badge badge-success mb-2">
                        <?php echo e(\Carbon\Carbon::now()->isoFormat('dddd, D MMMM Y')); ?> |
                        <span id="jam"></span></small>
                </center>
                <div class="form-inline">
                    <div class="input-group" data-widget="sidebar-search">
                        <input class="form-control form-control-sidebar" type="search" placeholder="Cari"
                            aria-label="Search">
                        <div class="input-group-append">
                            <button class="btn btn-sidebar">
                                <i class="fas fa-search fa-fw"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">

                        <?php echo $__env->make('admin.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </nav>
            </div>
        </aside>
        <div class="content-wrapper">
            <div id="alerts"></div>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->yieldContent('modal'); ?>
        </div>
    </div>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>