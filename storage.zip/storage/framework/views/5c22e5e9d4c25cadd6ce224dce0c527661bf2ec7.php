<!-- ======= Footer ======= -->
<footer id="footer">

    <div class="footer-top">
        <div class="container-footer">
            <div class="row-footer">
                <div class="col-lg-4 col-md-6 footer-contact">
                    <div class="d-flex align-items-center justify-content-between">
                        <img src="<?php echo e(url('front/img/logo-sipenaku-white.png')); ?>"class="img-fluid mb-3" style="width:45%"
                            alt="">
                    </div>
                    <p><?php echo e(old('keterangan_aplikasi', $appsetting->keterangan_aplikasi ?? '')); ?></p>
                </div>

                <div class="col-lg-4 col-md-6 footer-newsletter">
                    <h4>Pemerintah Kabupaten Batu bara</h4>
                    <p>Jl. Perintis Kemerdekaan, Lima Puluh Kota, Kec. Lima Puluh, Kabupaten Batu Bara, Sumatera Utara
                        21255</p>
                </div>

            </div>
        </div>
    </div>

    <div class="container-footer">
        <div class="copyright-wrap d-md-flex py-4">
            <div class="me-md-auto text-center text-md-start">
                <div class="copyright">
                    Copyright &copy; <?php echo e(date('Y')); ?> Bagian Keuangan Sekretariat Daerah Kabupaten Batu Bara. All
                    rights
                    reserved.
                </div>
            </div>
        </div>
    </div>
</footer><!-- End Footer -->

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
        class="bi bi-arrow-up-short"></i></a>
<div id="preloader"></div>

<!-- Vendor JS Files -->
<script src="<?php echo e(url('front/vendor/purecounter/purecounter_vanilla.js')); ?>"></script>
<script src="<?php echo e(url('front/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(url('front/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('front/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(url('front/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(url('front/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('front/vendor/php-email-form/validate.js')); ?>"></script>


<!-- Template Main JS File -->
<script src="<?php echo e(url('front/js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>