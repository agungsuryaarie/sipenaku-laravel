
<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="card mt-4">
                <div class="card-header">
                    <span class="text-bold"><?php echo e($menu); ?></span>
                </div>
                <div class="card-body">
                    <div class="col-12">
                        <div class="row">
                            <div class="col-1">
                                <div>Kegiatan</div>
                            </div>
                            <div class="col-8">
                                <div>: <?php echo e($kegiatan->kode_kegiatan); ?> <?php echo e($kegiatan->nama_kegiatan); ?></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-1">
                                <div>Bagian</div>
                            </div>
                            <div class="col-8">
                                <div>: <?php echo e($kegiatan->bagian->nama_bagian); ?></div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="javascript:void(0)" id="createNewSubkeg" class="btn btn-info btn-xs">
                                <i class="fas fa-plus-circle"></i> Tambah
                            </a>
                            <a href="<?php echo e(route('kegiatan.index')); ?>" id="createNewSubkeg"
                                class="btn btn-warning btn-xs float-right">
                                <i class="fas fa-reply"></i> Kembali
                            </a>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-striped data-table">
                                <thead>
                                    <tr>
                                        <th style="width:3%">No</th>
                                        <th style="width:15%">Kode Sub Kegiatan</th>
                                        <th>Nama Sub Kegiatan</th>
                                        <th class="text-center" style="width: 10%">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="modal fade" id="ajaxModel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modelHeading"></h4>
                </div>
                <div class="modal-body">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert" style="display: none;">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="subkegForm" name="subkegForm" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="subkeg_id" id="subkeg_id">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="hidden" id="id_kegiatan" name="id_kegiatan" value="<?php echo e($kegiatan->id); ?>">
                                    <label>Kegiatan</label>
                                    <input type="text" class="form-control"
                                        placeholder="<?php echo e($kegiatan->kode_kegiatan); ?> <?php echo e($kegiatan->nama_kegiatan); ?>"
                                        disabled>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Kode Sub Kegiatan<span class="text-danger">
                                            *</span></label>
                                    <input type="text" class="form-control" id="kode_sub" name="kode_sub"
                                        placeholder="Kode Sub">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Nama Sub Kegiatan<span class="text-danger">
                                            *</span></label>
                                    <input type="text" class="form-control" id="nama_sub" name="nama_sub"
                                        placeholder="Nama Sub">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-primary" id="saveBtn" value="create">Simpan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            $.ajaxSetup({
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
                },
            });

            var table = $(".data-table").DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('subkegiatan.index', $id)); ?>",
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'kode_subkeg',
                        name: 'kode_subkeg'
                    },
                    {
                        data: 'nama_subkeg',
                        name: 'nama_subkeg'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });

            $("#createNewSubkeg").click(function() {
                $("#saveBtn").val("create-subkeg");
                $("#subkeg_id").val("");
                $("#subkegForm").trigger("reset");
                $("#modelHeading").html("Tambah Sub Kegiatan");
                $("#ajaxModel").modal("show");
                $("#deleteSubkeg").modal("show");
            });

            $("body").on("click", ".editSubkeg", function() {
                var subkeg_id = $(this).data("id");
                $.get("<?php echo e(route('subkegiatan.index', $kegiatan->id)); ?>" + "/" + subkeg_id + "/edit",
                    function(data) {
                        $("#modelHeading").html("Edit Sub Kegiatan");
                        $("#saveBtn").val("edit-subkeg");
                        $("#ajaxModel").modal("show");
                        $("#subkeg_id").val(data.id);
                        $("#id_kegiatan").val(data.id_kegiatan);
                        $("#kode_sub").val(data.kode_sub);
                        $("#nama_sub").val(data.nama_sub);
                    });
            });

            $("#saveBtn").click(function(e) {
                e.preventDefault();
                $(this).html("menyimpan..");

                $.ajax({
                    data: $("#subkegForm").serialize(),
                    url: "<?php echo e(route('subkegiatan.store')); ?>",
                    type: "POST",
                    dataType: "json",
                    success: function(data) {
                        if (data.errors) {
                            $('.alert-danger').html('');
                            $.each(data.errors, function(key, value) {
                                $('.alert-danger').show();
                                $('.alert-danger').append('<strong><li>' +
                                    value +
                                    '</li></strong>');
                                $(".alert-danger").fadeOut(5000);
                                $("#saveBtn").html("Simpan");
                                $('#subkegForm').trigger("reset");
                            });
                        } else {
                            table.draw();
                            alertSuccess("Kegiatan Berhasil di tambah");
                            $('#subkegForm').trigger("reset");
                            $("#saveBtn").html("Simpan");
                            $('#ajaxModel').modal('hide');
                        }
                    },
                });
            });

            $("body").on("click", ".deleteSubkeg", function() {
                var subkeg_id = $(this).data("id");
                confirm("Are You sure want to delete !");
                $.ajax({
                    type: "DELETE",
                    url: "<?php echo e(route('subkegiatan.store')); ?>" + "/" + subkeg_id + "/destroy",
                    data: {
                        _token: "<?php echo csrf_token(); ?>",
                    },
                    success: function(data) {
                        alertDanger("Sub Kegiatan Berhasil di hapus");
                        table.draw();
                    },
                    error: function(data) {
                        console.log("Error:", data);
                    },
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/admin/sub-kegiatan/data.blade.php ENDPATH**/ ?>