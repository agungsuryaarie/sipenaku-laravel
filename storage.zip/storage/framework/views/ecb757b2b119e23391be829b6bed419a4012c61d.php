<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0"><?php echo e($menu); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e('dashboard'); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active"><?php echo e($menu); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-4">
                        <div class="card card-widget widget-user">
                            <div class="widget-user-header bg-info">
                                <h3 class="widget-user-username"><?php echo e(Auth::user()->nama); ?></h3>
                                <h5 class="widget-user-desc"><?php echo e(Auth::user()->bagian->nama_bagian); ?></h5>
                            </div>
                            <div class="widget-user-image">
                                <?php if(Auth::user()->foto == null): ?>
                                    <img src="<?php echo e(url('fotouser/blank.png')); ?>" class="img-circle elevation-2"
                                        alt="User Image">
                                <?php else: ?>
                                    <img src="<?php echo e(url('storage/fotouser/' . Auth::user()->foto)); ?>"
                                        class="img-circle elevation-2" alt="User Image">
                                <?php endif; ?>
                            </div>
                            <div class="card-footer">
                                <div class="col-sm-12 text-center">
                                    <div class="description-block mt-5 mb-4">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="invoice p-3 mb-3">
                            <div class="row">
                                <div class="col-12">
                                    <h4>
                                        <i class="fas fa-user"></i> Profil Saya
                                        <div class="float-right">
                                            <a href="#" class="btn btn-warning btn-xs text-white" title="Ubah Profil"
                                                data-toggle="modal" data-target="#modal-lg-p<?php echo e($user->id); ?>">
                                                <i class="fa fa-edit">
                                                </i>
                                            </a>
                                            <a href="#" class="btn btn-warning btn-xs text-white"
                                                title="Ubah Password" data-toggle="modal"
                                                data-target="#modal-lg-ps<?php echo e($user->id); ?>">
                                                <i class="fa fa-key">
                                                </i>
                                            </a>
                                            <a href="#" class="btn btn-warning btn-xs text-white" title="Ubah Foto"
                                                data-toggle="modal" data-target="#modal-lg-f<?php echo e($user->id); ?>">
                                                <i class="fa fa-camera">
                                                </i>
                                            </a>
                                        </div>
                                    </h4>
                                </div>
                            </div>
                            <div class="col-sm-4 invoice-col mt-4">
                                <h6><b>NIP</b></h6>
                                <span><?php echo e($user->nip); ?></span>
                                <h6 class="mt-2"><b>Nama</b></h6>
                                <span><?php echo e($user->nama); ?></span>
                                <h6 class="mt-2"><b>Email</b></h6>
                                <span><?php echo e($user->email); ?></span>
                                <h6 class="mt-2"><b>Username</b></h6>
                                <span><?php echo e($user->username); ?></span>
                                <h6 class="mt-2"><b>Nomor Handphone</b></h6>
                                <span><?php echo e($user->nohp); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <div class="modal fade" id="modal-lg-p<?php echo e($user->id); ?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Update Profil</h4>
                </div>
                <div class="modal-body">
                    <div class="card">
                        <form method="POST" action="<?php echo e(route('myprofil.update', $user->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                            <div class="card-body">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>NIP <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" value="<?php echo e(old('nip', $user->nip)); ?>"
                                            disabled>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Nama <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="nama" placeholder="Nama"
                                            autocomplete="off" value="<?php echo e(old('nama', $user->nama)); ?>">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Email <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="email" placeholder="Email"
                                            autocomplete="off" value="<?php echo e(old('email', $user->email)); ?>">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Username <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="username" placeholder="Username"
                                            autocomplete="off" value="<?php echo e(old('username', $user->username)); ?>">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Nomor Handphone <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="nohp"
                                            placeholder="Nomor Handphone" autocomplete="off"
                                            value="<?php echo e(old('nohp', $user->nohp)); ?>">
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="button" class="btn btn-default btn-sm"
                                        data-dismiss="modal">Kembali</button>
                                    <button type="submit" class="btn btn-primary btn-sm">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="modal-lg-ps<?php echo e($user->id); ?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Update Password</h4>
                </div>
                <div class="modal-body">
                    <div class="card">
                        <form method="POST" action="<?php echo e(route('myprofil.update.password', $user->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                            <div class="card-body">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>New Password <span class="text-danger">*</span></label>
                                        <input type="password" name="npassword" class="form-control"
                                            value="<?php echo e(old('npassword')); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Re-Password <span class="text-danger">*</span></label>
                                        <input type="password" name="nrepassword" class="form-control"
                                            value="<?php echo e(old('rpassword')); ?>" required>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="button" class="btn btn-default btn-sm"
                                        data-dismiss="modal">Kembali</button>
                                    <button type="submit" class="btn btn-primary btn-sm">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="modal-lg-f<?php echo e($user->id); ?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Update Foto</h4>
                </div>
                <div class="modal-body">
                    <div class="card">
                        <form method="POST" action="<?php echo e(route('myprofil.update.foto', $user->id)); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                            <div class="card-body">
                                <div class="col-md-12">
                                    <div class="col-md-4">
                                        <img src="<?php echo e(url('fotouser/blank.png')); ?>" alt="Image Profile"
                                            class="img-thumbnail rounded img-preview" width="120px">
                                    </div>
                                    <div class="col-md-12 mt-2">
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" name="foto" class="custom-file-input"
                                                    id="foto" onchange="previewImg();" accept=".png, .jpg, .jpeg"
                                                    required>
                                                <label class="custom-file-label">Pilih File</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="button" class="btn btn-default btn-sm"
                                        data-dismiss="modal">Kembali</button>
                                    <button type="submit" class="btn btn-primary btn-sm">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function previewImg() {
            const foto = document.querySelector('#foto');
            const img = document.querySelector('.img-preview');

            const fileFoto = new FileReader();
            fileFoto.readAsDataURL(foto.files[0]);

            fileFoto.onload = function(e) {
                img.src = e.target.result;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/admin/myprofil/data.blade.php ENDPATH**/ ?>