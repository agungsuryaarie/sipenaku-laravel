<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0"><?php echo e($menu); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e('/dashboard'); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active"><?php echo e($menu); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <?php if($appsetting != null): ?>
        <section class="content">
            <div class="container-fluid">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="float-right">
                                <a href="<?php echo e(route('appsetting.edit', Crypt::encryptString($appsetting->id))); ?>"
                                    class="btn btn-warning btn-xs text-white">
                                    <i class="fa fa-edit">
                                    </i></a>
                            </div>
                        </div>
                        <div class=" table-responsive">
                            <table class="table">
                                <tr>
                                    <td style="width:4%">
                                        Nama Aplikasi
                                    </td>
                                    <td style="width:0%">
                                        :
                                    </td>
                                    <td style="width:20%">
                                        <?php echo e($appsetting->nama_aplikasi); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Keterangan Aplikasi
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <?php echo e($appsetting->keterangan_aplikasi); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Visi
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <?php echo $appsetting->visi; ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Misi
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <?php echo $appsetting->misi; ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Logo Aplikasi
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <img class="profile-user-img img-fluid"
                                            src="<?php echo e(url('storage/logo/' . $appsetting->gambar)); ?>"
                                            alt="User profile picture">
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php else: ?>
        <div class="container-fluid">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-right">
                            <a href="<?php echo e(route('appsetting.create')); ?>" class="btn btn-info btn-xs">
                                <i class="fa fa-plus-circle">
                                </i></a>
                        </div>
                    </div>
                    <div class="card-body text-center">
                        <h6>Opss, profil aplikasi belum diatur . . .</h6><br>
                        <img class="mb-5 mt-5" src="<?php echo e(url('dist/img/ils/set.png')); ?>" width="150px">
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/admin/app-setting/data.blade.php ENDPATH**/ ?>