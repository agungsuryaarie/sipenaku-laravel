<nav id="navbar" class="navbar">
    <ul>
        <li><a class="nav-link scrollto active" href="#hero">Beranda</a></li>
        <li><a class="nav-link scrollto" href="#visi-misi">Visi Misi</a></li>
        <li><a class="nav-link scrollto" href="#features">Fitur</a></li>
        <li><a class="getstarted scrollto" href="<?php echo e('/login'); ?>">Login</a></li>
    </ul>
    <i class="bi bi-list mobile-nav-toggle"></i>
</nav><!-- .navbar -->
<?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>