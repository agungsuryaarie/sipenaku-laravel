    

    <script src="<?php echo e(asset('/')); ?>dist/login/js/jquery.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>dist/login/js/popper.js"></script>
    <script src="<?php echo e(asset('/')); ?>dist/login/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>dist/login/js/main.js"></script>

    </body>

    </html>
<?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/auth/layouts-log/js.blade.php ENDPATH**/ ?>