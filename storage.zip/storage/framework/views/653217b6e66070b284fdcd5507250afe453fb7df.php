<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($menu); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active"><?php echo e($menu); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="col-md-12">

                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h5>Ketentuan :</h6>
                        <small>
                            *Harap lihat kartu kendali sebelum input SPJ untuk memastikan nilai kwitansi.<br>
                            *Nilai kwitansi tidak boleh melebihi nilai anggaran.<br>
                            *Jika tidak memperbaharui file, kosongkan saja.<br>
                            *Berkas file digabung dalam 1 file dan wajib berbentuk pdf.<br>
                            *Ukuran file maksimal 5MB.
                </div>
                <div class="card">
                    <form method="POST" action="<?php echo e(route('spj.update', Crypt::encryptString($spj->id))); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="card-body-form">
                            <div class="form-group">
                                <label>Tanggal<small> (Opsional)</small></label>
                                <input type="date" name="tanggal" class="form-control"
                                    value="<?php echo e(old('tanggal', $spj->tanggal)); ?>">
                            </div>
                            <div class="form-group">
                                <label>Kegiatan<span class="text-danger"> *</span></label>
                                <select class="form-control select2bs4 <?php $__errorArgs = ['kegiatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="kegiatan" name="kegiatan_id" style="width: 100%;">
                                    <option value="">::Pilih Kegiatan::</option>
                                    <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($keg->id); ?>"
                                            <?php echo e($keg->id == $spj->kegiatan_id ? 'selected' : ''); ?>>
                                            <?php echo e($keg->nama_kegiatan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['kegiatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Sub Kegiatan<span class="text-danger"> *</span></label>
                                <select id="subkeg" name="subkegiatan_id"
                                    class="form-control select2bs4 <?php $__errorArgs = ['subkegiatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                </select>
                                <?php $__errorArgs = ['subkegiatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Rekening Belanja<span class="text-danger"> *</span></label>
                                <select id="rekening" name="rekening_id"
                                    class="form-control select2bs4 <?php $__errorArgs = ['rekening_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                </select>
                                <?php $__errorArgs = ['rekening_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Uraian<span class="text-danger"> *</span></label>
                                <textarea name="uraian" class="form-control <?php $__errorArgs = ['uraian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3"><?php echo e(old('uraian', $spj->uraian)); ?></textarea>
                                <?php $__errorArgs = ['uraian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Nilai Kwitansi<span class="text-danger"> *</span></label>
                                <input name="kwitansi" type="text"
                                    class="form-control <?php $__errorArgs = ['kwitansi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Rp."
                                    value="<?php echo e(old('kwitansi', $spj->kwitansi)); ?>" id="kwitansi">
                                <?php $__errorArgs = ['kwitansi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Nama Rekanan/Penerima<span class="text-danger"> *</span></label>
                                <input name="nama_penerima" type="text"
                                    class="form-control <?php $__errorArgs = ['nama_penerima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('nama_penerima', $spj->nama_penerima)); ?>">
                                <?php $__errorArgs = ['nama_penerima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Alamat Penerima<span class="text-danger"> *</span></label>
                                <textarea name="alamat_penerima" class="form-control  <?php $__errorArgs = ['alamat_penerima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3"><?php echo e(old('alamat_penerima', $spj->alamat_penerima)); ?></textarea>
                                <?php $__errorArgs = ['alamat_penerima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Jenis SPM<span class="text-danger"> *</span></label>
                                <div class="radio-btn">
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" value="1" id="jenis_spm1"
                                            name="jenis_spm" <?php echo e(old('jenis_spm', $spj->jenis_spm) == 1 ? 'checked' : ''); ?>>
                                        <label for="jenis_spm1" class="custom-control-label">GU</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" value="2" id="jenis_spm2"
                                            name="jenis_spm" <?php echo e(old('jenis_spm', $spj->jenis_spm) == 2 ? 'checked' : ''); ?>>
                                        <label for="jenis_spm2" class="custom-control-label">TU</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" value="3" id="jenis_spm3"
                                            name="jenis_spm"
                                            <?php echo e(old('jenis_spm', $spj->jenis_spm) == 3 ? 'checked' : ''); ?>>
                                        <label for="jenis_spm3" class="custom-control-label">LS</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" value="4"
                                            id="jenis_spm4" name="jenis_spm"
                                            <?php echo e(old('jenis_spm', $spj->jenis_spm) == 4 ? 'checked' : ''); ?>>
                                        <label for="jenis_spm4" class="custom-control-label">UP</label>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['jenis_spm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><strong><?php echo e($message); ?></strong></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <a href="<?php echo e(url('storage/file/', $spj->file)); ?>" target="blank"
                                    class="link-blue text-sm"><i class="fas fa-link mr-1"></i> File Lama</a>
                            </div>
                            <div class="form-group">
                                <label>Upload File Baru <small>(Opsional)</small></label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="file" id="customFile" accept=".pdf">
                                    <label class="custom-file-label">Pilih File</label>
                                </div>
                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><strong><?php echo e($message); ?></strong></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-sm">
                                Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        var rupiah = document.getElementById("kwitansi");
        rupiah.addEventListener("keyup", function(e) {
            rupiah.value = formatRupiah(this.value, "Rp. ");
        });


        /* Fungsi formatRupiah */
        function formatRupiah(angka, prefix) {
            var number_string = angka.replace(/[^,\d]/g, "").toString(),
                split = number_string.split(","),
                sisa = split[0].length % 3,
                rupiah = split[0].substr(0, sisa),
                ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            // tambahkan titik jika yang di input sudah menjadi angka ribuan
            if (ribuan) {
                separator = sisa ? "." : "";
                rupiah += separator + ribuan.join(".");
            }

            rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
            return prefix == undefined ? rupiah : rupiah ? "Rp. " + rupiah : "";
        }

        $('.select2bs4').select2({
            theme: 'bootstrap4'
        })
        $(function() {
            bsCustomFileInput.init();
        });
        $('#kegiatan').on('change', function() {
            var idKegiatan = $('#kegiatan').val();
            $("#subkeg").html('');
            $.ajax({
                url: "<?php echo e(route('spj.getsubkeg')); ?>",
                type: "POST",
                data: {
                    kegiatan_id: idKegiatan,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function(result) {
                    $('#subkeg').html('<option value="">Pilih Sub Kegiatan</option>');
                    $.each(result.subkeg, function(key, value) {
                        $("#subkeg").append('<option value="' + value
                            .id + '">' + value.nama_sub + '</option>');
                    });
                }
            });
            $('#subkeg').on('change', function() {
                var idSubkeg = $('#subkeg').val();
                console.log(idSubkeg);
                $("#rekening").html('');
                $.ajax({
                    url: "<?php echo e(route('spj.getrekening')); ?>",
                    type: "POST",
                    data: {
                        subkeg_id: idSubkeg,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function(result) {
                        $('#rekening').html('<option value="">Pilih Rekening</option>');
                        $.each(result.rekening, function(key, value) {
                            $("#rekening").append('<option value="' + value
                                .id + '">' + value.nama_rekening + '</option>');
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/admin/spj/edit.blade.php ENDPATH**/ ?>