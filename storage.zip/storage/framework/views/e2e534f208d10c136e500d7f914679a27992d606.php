<?php $__env->startSection('content'); ?>
    <div class="panel-header bg-secondary">
        <div class="page-inner py-4">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h4 class="text-white pb-2 fw-bold">Dashboard <?php if(Auth::user()->level == 1): ?>
                                    Administrator
                                <?php else: ?>
                                    <?php echo e(Auth::user()->bagian->nama_bagian); ?>

                                <?php endif; ?>
                                </h2>
                                <h5 class="text-white op-7 mb-2"><?php echo e($app->nama_aplikasi); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div class="ml-md-auto">
                    <?php if($gu != null): ?>
                        <?php if(date('Y-m-d') < $gu->tgl_mulai && date('H:i:s') < $gu->jam_mulai): ?>
                            <a href="#" class="btn btn-success btn-round btn-xs mr-2 mb-2"><i
                                    class="fa fa-wallet"></i>&nbsp;&nbsp;<?php echo e($gu->judul); ?> mulai
                                <?php echo e(\Carbon\Carbon::parse($gu->tgl_mulai)->translatedFormat('l, d F Y')); ?>

                                </td> | Pukul : <?php echo e($gu->jam_mulai); ?> -
                                <?php echo e(\Carbon\Carbon::parse($gu->tgl_selesai)->translatedFormat('l, d F Y')); ?>

                                </td> | Pukul : <?php echo e($gu->jam_selesai); ?></a>
                            <a href="#" class="btn btn-warning btn-round btn-xs mb-2 text-white mr-2"><i
                                    class="fas fa-clock"></i>&nbsp;&nbsp;sesi belum dimulai</a>
                        <?php elseif(date('Y-m-d') == $gu->tgl_mulai && date('H:i:s') < $gu->jam_mulai): ?>
                            <a href="#" class="btn btn-success btn-round btn-xs mr-2 mb-2"><i
                                    class="fa fa-wallet"></i>&nbsp;&nbsp;<?php echo e($gu->judul); ?> mulai
                                <?php echo e(\Carbon\Carbon::parse($gu->tgl_mulai)->translatedFormat('l, d F Y')); ?>

                                </td> | Pukul : <?php echo e($gu->jam_mulai); ?> -
                                <?php echo e(\Carbon\Carbon::parse($gu->tgl_selesai)->translatedFormat('l, d F Y')); ?>

                                </td> | Pukul : <?php echo e($gu->jam_selesai); ?></a>
                            <a href="#" class="btn btn-warning btn-round btn-xs mb-2 text-white mr-2"><i
                                    class="fas fa-clock"></i>&nbsp;&nbsp;sesi belum dimulai</a>
                        <?php elseif(date('Y-m-d') > $gu->tgl_mulai ||
                                (date('Y-m-d') == $gu->tgl_mulai && date('Y-m-d') < $gu->tgl_selesai) ||
                                (date('Y-m-d') == $gu->tgl_selesai && date('H:i:s') > $gu->jam_mulai && date('H:i:s') < $gu->jam_selesai)): ?>
                            <a href="#" class="btn btn-success btn-round btn-xs mr-2 ml-2">
                                <i class="fa fa-wallet"></i>&nbsp;&nbsp;<?php echo e($gu->judul); ?> mulai
                                <?php echo e(\Carbon\Carbon::parse($gu->tgl_mulai)->translatedFormat('l, d F Y')); ?>

                                </td> | Pukul : <?php echo e($gu->jam_mulai); ?> -
                                <?php echo e(\Carbon\Carbon::parse($gu->tgl_selesai)->translatedFormat('l, d F Y')); ?>

                                </td> | Pukul : <?php echo e($gu->jam_selesai); ?></a>
                            <a href="#" class="btn btn-danger btn-round btn-xs mr-2 ml-2"><i
                                    class="fas fa-clock"></i>&nbsp;&nbsp;
                                <span id="berakhir"></span></a>
                        <?php else: ?>
                            <a href="#" class="btn btn-success btn-round btn-xs mr-2 ml-2">
                                <i class="fa fa-wallet"></i>&nbsp;&nbsp;<?php echo e($gu->judul); ?> mulai
                                <?php echo e(\Carbon\Carbon::parse($gu->tgl_mulai)->translatedFormat('l, d F Y')); ?>

                                </td> | Pukul : <?php echo e($gu->jam_mulai); ?> -
                                <?php echo e(\Carbon\Carbon::parse($gu->tgl_selesai)->translatedFormat('l, d F Y')); ?>

                                </td> | Pukul : <?php echo e($gu->jam_selesai); ?></a>
                            <a href="#" class="btn btn-danger btn-round btn-xs mr-2 ml-2"><i
                                    class="fas fa-clock"></i>&nbsp;&nbsp;
                                <span id="berakhir"></span></a>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="#" class="btn btn-success btn-round btn-xs mr-2 mb-2"><i
                                class="fa fa-wallet"></i>&nbsp;&nbsp;Belum ada GU</a>
                        <a href="#" class="btn btn-danger btn-round btn-xs mb-2 mr-2"><i
                                class="fas fa-clock"></i>&nbsp;&nbsp;<span id="berakhir"></span></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Main content -->
    <section class="content mt-2">
        <div class="container-fluid">
            <?php if(Auth::user()->level == 1): ?>
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3><?php echo e($bagian); ?></h3>
                                <p>Bagian</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-building"></i>
                            </div>
                            <a href="<?php echo e('bagian'); ?>" class="small-box-footer">Selengkapnya <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3><?php echo e($user); ?></h3>
                                <p>Account User</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-user-check"></i>
                            </div>
                            <a href="<?php echo e('user'); ?>" class="small-box-footer">Selengkapnya <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3><?php echo e($kegiatan_all); ?></h3>
                                <p>Kegiatan</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-list"></i>
                            </div>
                            <a href="<?php echo e('kegiatan'); ?>" class="small-box-footer">Selengkapnya <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3><?php echo e($spj); ?></h3>
                                <p>SPJ</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-file"></i>
                            </div>
                            <a href="<?php echo e(route('spj.diterima')); ?>" class="small-box-footer">Selengkapnya <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
    </section>
    <?php if(Auth::user()->level == 2): ?>
        <section class="content">
            <div class="col-md-12">
                <div class="card-footer bg-white shadow-sm">
                    <div class="row">
                        
                        <div class="col-sm-3 col-6">
                            <div class="description-block border-right">
                                <h5 class="description-header mt-4">SPJ Diterima</h5>
                                <span class="description-text text-success"><?php echo e($spj_terima); ?></span>
                            </div>
                        </div>
                        <div class="col-sm-3 col-6">
                            <div class="description-block border-right">
                                <h5 class="description-header mt-4">SPJ Ditolak</h5>
                                <span class="description-text text-danger"><?php echo e($spj_tolak); ?></span>
                            </div>
                        </div>
                        <div class="col-sm-3 col-6">
                            <div class="description-block border-right">
                                <h5 class="description-header mt-4">Anggaran</h5>
                                <span class="description-text">
                                    <?php if(Auth::user()->level == 2): ?>
                                        <span
                                            class="description-text text-success"><?php echo e('Rp. ' . number_format($pagu_kegiatan->pagu, 0, ',', '.')); ?></span>
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                        <div class="col-sm-3 col-6">
                            <div class="description-block">
                                <h5 class="description-header mt-4">Sisa</h5>
                                <span class="description-text">
                                    <?php if(Auth::user()->level == 2): ?>
                                        <span
                                            class="description-text text-danger"><?php echo e('Rp. ' . number_format($sisa_kegiatan->sisa, 0, ',', '.')); ?></span>
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        <?php if(!$gu == null): ?>
            var countDownDate4 = new Date("<?php echo e($gu->tgl_selesai); ?> <?php echo e($gu->jam_selesai); ?>").getTime();
        <?php else: ?>
            var countDownDate4 = new Date().getTime();
        <?php endif; ?>
        var countdownfunction4 = setInterval(function() {
            var now = new Date().getTime();
            var distance4 = countDownDate4 - now;
            var days4 = Math.floor(distance4 / (1000 * 60 * 60 * 24));
            var hours4 = Math.floor(
                (distance4 % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
            );
            var minutes4 = Math.floor((distance4 % (1000 * 60 * 60)) / (1000 * 60));
            var seconds4 = Math.floor((distance4 % (1000 * 60)) / 1000);
            document.getElementById("berakhir").innerHTML = "Berakhir dalam " +
                days4 + " hari " + hours4 + " jam " + minutes4 + " menit " + seconds4 + " detik " +
                "lagi . . .";
            if (distance4 < 0) {
                clearInterval(countdownfunction4);
                document.getElementById("berakhir").innerHTML = "sesi telah berakhir";
            }
        }, 1000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>