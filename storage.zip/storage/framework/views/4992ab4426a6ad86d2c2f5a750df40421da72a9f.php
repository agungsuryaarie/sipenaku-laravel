<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($menu); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active"><?php echo e($menu); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped data-table">
                                <thead>
                                    <tr>
                                        <th style="width: 5%">No</th>
                                        <th style="width: 10%">Tanggal</th>
                                        <th style="width: 20%">Bagian</th>
                                        <th>Uraian</th>
                                        <th class="text-center" style="width: 8%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            $.ajaxSetup({
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
                },
            });

            var table = $(".data-table").DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('spj.verifikasi')); ?>",
                columns: [{
                        data: "DT_RowIndex",
                        name: "DT_RowIndex",
                    },
                    {
                        data: "tanggal",
                        name: "tanggal",
                    },
                    {
                        data: "bagian",
                        name: "bagian",
                    },
                    {
                        data: "uraian",
                        name: "uraian",
                    },
                    {
                        data: "action",
                        name: "action",
                        orderable: false,
                        searchable: false,
                    },
                ],
            });

            // $("body").on("click", ".deleteSpj", function() {
            //     var spj_id = $(this).data("id");
            //     confirm("Are You sure want to delete !");

            //     $.ajax({
            //         type: "DELETE",
            //         url: "<?php echo e(url('spj/destroy')); ?>" + '/' + spj_id,
            //         data: {
            //             _token: "<?php echo csrf_token(); ?>",
            //         },
            //         success: function(data) {
            //             alertDanger("SPJ Berhasil di hapus");
            //             table.draw();
            //         },
            //         error: function(data) {
            //             console.log("Error:", data);
            //         },
            //     });
            // });

            // $("body").on("click", ".terima", function() {
            //     var spj_id = $(this).data("id");
            //     $.ajax({
            //         type: "POST",
            //         url: "<?php echo e(url('spj/terima')); ?>" + '/' + spj_id,
            //         data: {
            //             _token: "<?php echo csrf_token(); ?>",
            //         },
            //         success: function(data) {
            //             alertSuccess("SPJ Berhasil diterima");
            //             table.draw();
            //         },
            //         error: function(data) {
            //             console.log("Error:", data);
            //         },
            //     });
            // });

            // $("body").on("click", ".kembalikan", function() {
            //     var spj_id = $(this).data("id");
            //     $.ajax({
            //         type: "POST",
            //         url: "<?php echo e(url('spj/kembalikan')); ?>" + '/' + spj_id,
            //         data: {
            //             _token: "<?php echo csrf_token(); ?>",
            //         },
            //         success: function(data) {
            //             alertSuccess("SPJ Berhasil dikembalikan");
            //             table.draw();
            //         },
            //         error: function(data) {
            //             console.log("Error:", data);
            //         },
            //     });
            // });

            // $("body").on("click", ".tolak", function() {
            //     var spj_id = $(this).data("id");
            //     $.ajax({
            //         type: "POST",
            //         url: "<?php echo e(url('spj/tolak')); ?>" + '/' + spj_id,
            //         data: {
            //             _token: "<?php echo csrf_token(); ?>",
            //         },
            //         success: function(data) {
            //             alertSuccess("SPJ Berhasil ditolak");
            //             table.draw();
            //         },
            //         error: function(data) {
            //             console.log("Error:", data);
            //         },
            //     });
            // });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipenaku-laravel\resources\views/admin/spj/verifikasi.blade.php ENDPATH**/ ?>